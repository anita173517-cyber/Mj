# Build the Single Release APK on GitHub Actions (Mobile Friendly)

1. Open your GitHub repository in Chrome (Mobile or Desktop mode).
2. Upload `StreamX_Media3_Pro_v14.0_Hyper_Glass_4D_GitHub_Ready.zip` to the repository root (or extract its files directly) and commit.
3. Open `.github/workflows/build_apk.yml` in your repository (or create it via **Actions** → **New workflow** → **set up a workflow yourself**) and paste the contents of `StreamX_GitHub_Actions_build_apk.yml`.
4. Commit the workflow file, then open **Actions** → **StreamX Media3 Pro - Single Release APK** → **Run workflow**.
5. Once the workflow finishes, download the artifact **`StreamX-Media3-Pro-v14.0-Hyper-Glass-4D-Release`** (`StreamX-Media3-Pro-v14.0-Hyper-Glass-4D-512MB.apk`).
