package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.io.Reader
import java.net.SocketTimeoutException

class M3uParserTest {
    @Test
    fun parsesMetadataAndChannelUrl() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="news.in" tvg-logo="https://cdn.example/logo.png" group-title="News",India News HD
https://stream.example/news/index.m3u8
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("India News HD", channels[0].name)
        assertEquals("News", channels[0].category)
        assertEquals("news.in", channels[0].epgId)
        assertEquals("https://cdn.example/logo.png", channels[0].logoUrl)
        assertEquals("https://stream.example/news/index.m3u8", channels[0].streamUrl)
    }

    @Test
    fun removesUtf8BomAndDeduplicatesIdenticalStreamUrls() {
        val playlist = "\uFEFF" + """#EXTM3U
#EXTINF:-1,First
https://stream.example/live.m3u8
#EXTINF:-1,Duplicate
https://stream.example/live.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("First", channels.first().name)
    }

    @Test
    fun supportsReaderInputAndChannelLimit() {
        val playlist = """#EXTM3U
#EXTINF:-1,One
https://stream.example/1.m3u8
#EXTINF:-1,Two
https://stream.example/2.m3u8
"""
        val channels = M3uParser.parse(playlist.reader(), maxChannels = 1)
        assertEquals(1, channels.size)
        assertTrue(channels.first().number == 1)
    }

    @Test
    fun attachesSecondDistinctStreamUrlAsBackupUrlForSameChannelName() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/primary.m3u8
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/backup.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://stream.example/primary.m3u8", channels[0].streamUrl)
        assertEquals("https://stream.example/backup.m3u8", channels[0].backupUrl)
    }

    @Test
    fun normalizedPairHashIsCaseAndWhitespaceInsensitive() {
        val h1 = M3uParser.fnv1a64NormalizedPair("  Sports ", "  Star Sports 1 HD ")
        val h2 = M3uParser.fnv1a64NormalizedPair("sports", "star sports 1 hd")
        val h3 = M3uParser.fnv1a64NormalizedPair("Movies", "star sports 1 hd")
        assertEquals(h1, h2)
        assertNotEquals(h1, h3)
    }

    @Test
    fun handlesInvalidAndBrokenEntriesGracefully() {
        val playlist = """#EXTM3U
#EXTINF:-1
ftp://unsupported.example/file.ts
#EXTINF:-1 group-title="Movies",Valid Cinema HD
https://stream.example/cinema/live.m3u8
not_a_valid_url_line
""".trimIndent()
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("Valid Cinema HD", channels[0].name)
    }

    @Test
    fun extractsPipeAndExtVlcOptCustomHeadersAndRedactsCredentials() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="VIP",VIP Sports 1
#EXTVLCOPT:http-user-agent=CustomPlayer/2.0
#EXTVLCOPT:http-referrer=https://portal.example/
https://edge.example/live/ch1.m3u8?token=secret123|Authorization=Bearer%20tok999&Cookie=sid=abc
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://edge.example/live/ch1.m3u8?token=secret123", channels[0].streamUrl)

        val headers = NetworkClient.headersForUrl(channels[0].streamUrl)
        assertEquals("CustomPlayer/2.0", headers["User-Agent"])
        assertEquals("https://portal.example/", headers["Referer"])
        assertEquals("Bearer tok999", headers["Authorization"])
        assertEquals("sid=abc", headers["Cookie"])

        val redacted = NetworkClient.redactSensitiveUrl(
            "http://line.server.com:8080/live/harindra/mySecretPass/402.m3u8?token=xyz987&password=p1"
        )
        assertFalse(redacted.contains("mySecretPass"))
        assertFalse(redacted.contains("xyz987"))
        assertFalse(redacted.contains("p1"))
        assertTrue(redacted.contains("****"))
    }

    @Test
    fun parses30kAnd60kLargePlaylistsWithinLimit() {
        val totalToGenerate = 60_000
        val syntheticReader = object : Reader() {
            private var currentChannel = 0
            private var buffer = "#EXTM3U\n"
            private var pos = 0

            override fun read(cbuf: CharArray, off: Int, len: Int): Int {
                if (pos >= buffer.length) {
                    if (currentChannel >= totalToGenerate) return -1
                    currentChannel++
                    buffer = "#EXTINF:-1 group-title=\"Group${currentChannel % 20}\",Channel $currentChannel\nhttps://cdn.example/live/$currentChannel.m3u8\n"
                    pos = 0
                }
                val toCopy = (buffer.length - pos).coerceAtMost(len)
                buffer.toCharArray(cbuf, off, pos, pos + toCopy)
                pos += toCopy
                return toCopy
            }

            override fun close() {}
        }

        var firstBatchCount = 0
        val parsed = M3uParser.parse(
            reader = syntheticReader,
            maxChannels = 60_000,
            onFirstBatch = { firstBatchCount = it.size }
        )
        assertEquals(80, firstBatchCount)
        assertEquals(60_000, parsed.size)
        assertEquals("Channel 1", parsed.first().name)
        assertEquals("Channel 60000", parsed.last().name)
    }

    @Test
    fun detectsStreamFormatsAndParsesHlsPreloadTargetsWithTokenPreservation() {
        assertEquals(StreamPreFetcher.StreamFormat.HLS, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/ch1.m3u8?token=abc"))
        assertEquals(StreamPreFetcher.StreamFormat.DASH, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/manifest.mpd"))
        assertEquals(StreamPreFetcher.StreamFormat.RTSP, StreamPreFetcher.detectStreamFormat("rtsp://192.168.1.10:554/live"))
        assertEquals(StreamPreFetcher.StreamFormat.MPEG_TS, StreamPreFetcher.detectStreamFormat("http://line.server.com:8080/live/user/pass/101.ts"))

        val masterM3u8 = """#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=12000000,RESOLUTION=3840x2160
4k/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080
1080p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720
720p/index.m3u8
""".trimIndent()

        val masterPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/master.m3u8?wmsAuthSign=tok777",
            masterM3u8
        )
        assertTrue(masterPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777", masterPlan.variantPlaylistUrl)

        val mediaM3u8 = """#EXTM3U
#EXT-X-TARGETDURATION:4
#EXT-X-MAP:URI="init.mp4"
#EXTINF:4.0,
seg100.m4s
#EXTINF:4.0,
seg101.m4s
#EXTINF:4.0,
seg102.m4s
""".trimIndent()

        val mediaPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777",
            mediaM3u8
        )
        assertFalse(mediaPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/init.mp4?wmsAuthSign=tok777", mediaPlan.initSegmentUrl)
        assertNotNull(mediaPlan.firstMediaSegmentUrl)
        assertEquals("https://cdn.example/live/1080p/seg101.m4s?wmsAuthSign=tok777", mediaPlan.firstMediaSegmentUrl)
    }

    @Test
    fun classifiesHttpAuthAndServerErrorsAndValidatesMediaSegmentBytes() {
        assertNull(StreamPreFetcher.classifyHttpStatus(200))
        assertNull(StreamPreFetcher.classifyHttpStatus(206))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(401))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(403))
        assertEquals(StreamPreFetcher.PreloadState.NOT_FOUND, StreamPreFetcher.classifyHttpStatus(404))
        assertEquals(StreamPreFetcher.PreloadState.RATE_LIMITED, StreamPreFetcher.classifyHttpStatus(429))
        assertEquals(StreamPreFetcher.PreloadState.SERVER_ERROR, StreamPreFetcher.classifyHttpStatus(503))
        assertEquals(StreamPreFetcher.PreloadState.TIMEOUT, StreamPreFetcher.classifyException(SocketTimeoutException("Read timed out")))
        assertEquals(StreamPreFetcher.PreloadState.CANCELLED, StreamPreFetcher.classifyException(IOException("Canceled")))

        // Valid MPEG-TS packet (0x47 sync byte at 0 and 188)
        val tsPacket = ByteArray(376).apply {
            this[0] = 0x47
            this[188] = 0x47
        }
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(tsPacket, "video/mp2t"))

        // Valid fMP4 init segment (size + "ftyp")
        val fmp4Init = byteArrayOf(0, 0, 0, 24, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(fmp4Init, "video/mp4"))

        // Invalid HTML captive portal / error body masquerading as 200 OK
        val htmlError = "<html><body>403 Forbidden</body></html>".toByteArray(Charsets.UTF_8)
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "text/html"))
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "video/mp2t"))
    }

    @Test
    fun verifiesSaltedParentalPinHashAndRejectsWrongPin() {
        val salt = "0123456789abcdef0123456789abcdef"
        val hash = ProfileStore.computeSaltedPinHash("2580", salt)
        assertTrue(ProfileStore.verifySaltedPinHash("2580", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("1234", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("258", salt, hash))
    }

    @Test
    fun cancelsStaleGenerationAndTracksPreloadMissFallbackCleanly() {
        val genBefore = StreamPreFetcher.currentGenerationId()
        StreamPreFetcher.notifyChannelSwitched("https://cdn.example/live/ch10.m3u8", forwardDirection = true)
        val genAfter = StreamPreFetcher.currentGenerationId()
        assertTrue(genAfter > genBefore)

        // Unpreloaded channel returns null cleanly so caller falls back to normal playback
        val missedSource = StreamPreFetcher.consumePreparedMediaSource("https://cdn.example/live/unpreloaded.m3u8")
        assertNull(missedSource)
    }
}
